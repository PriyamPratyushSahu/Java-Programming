package lab1;

public class ques1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=Integer.parseInt(args[0]);
		if(num>0)
			System.out.println("+ve");
	}

}
