package string_programs;

public class Employee {
	String name;
	String ssn;
	String dept;
	int salary;
	public Employee(String name, String ssn, String dept, int salary) {
		super();
		this.name = name;
		this.ssn = ssn;
		this.dept = dept;
		this.salary = salary;
	}
	
}
