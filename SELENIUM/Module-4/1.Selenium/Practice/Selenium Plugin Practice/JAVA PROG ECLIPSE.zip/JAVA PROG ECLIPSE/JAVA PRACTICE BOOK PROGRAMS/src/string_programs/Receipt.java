package string_programs;

public class Receipt {
	TransactionParty transactionParty;
	String productsQR;
	public Receipt(TransactionParty transactionParty, String productsQR) {
		this.transactionParty = transactionParty;
		this.productsQR = productsQR;
	}
	
}
