package sample_programs;

public class AddImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Add a=new Add(2,3,0);
		int res=a.add();
		System.out.println(res);
	}

}
