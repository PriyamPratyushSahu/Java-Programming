package sample_programs;

interface Animal2 {
	
	

	public void eat();
	
	public void sleep();
	
	abstract void giveSound(); // ; means stmt ends here itself
}
