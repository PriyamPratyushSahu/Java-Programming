package sample_programs;

public class AnimalImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnimalTypes animalTypes1=new AnimalTypes("dog", "sharp", "sharp", 4, "");
				animalTypes1.eat();
		animalTypes1.sleep();
		animalTypes1.giveSound();
		AnimalTypes animalTypes2=new AnimalTypes("cat", "sharp", "sharp", 4, "");
				animalTypes2.eat();
		animalTypes2.sleep();
		animalTypes2.giveSound();

	}

}
