package sample_programs;

public class AnimalImpl2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnimalTypes2 animalTypes1=new AnimalTypes2("dog", "blunt", "sharp", 4, "");
				animalTypes1.eat();
		animalTypes1.sleep();
		animalTypes1.giveSound();
		AnimalTypes2 animalTypes2=new AnimalTypes2("cat", "sharp", "sharp", 4, "");
				animalTypes2.eat();
		animalTypes2.sleep();
		animalTypes2.giveSound();

	}

}
