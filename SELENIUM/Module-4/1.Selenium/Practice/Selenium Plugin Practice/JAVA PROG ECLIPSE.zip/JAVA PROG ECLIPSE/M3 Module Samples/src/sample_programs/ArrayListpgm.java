package sample_programs;

public class ArrayListpgm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//jk
	}

}
