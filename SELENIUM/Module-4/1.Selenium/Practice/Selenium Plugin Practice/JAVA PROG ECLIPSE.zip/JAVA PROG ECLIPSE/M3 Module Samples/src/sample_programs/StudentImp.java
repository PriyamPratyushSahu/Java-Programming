package sample_programs;

public class StudentImp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentCalculations studentcalculations=new StudentCalculations(0, 0, null, null, null, 0, 0, 0, 0, 0);
		studentcalculations.disp();
	}

}
