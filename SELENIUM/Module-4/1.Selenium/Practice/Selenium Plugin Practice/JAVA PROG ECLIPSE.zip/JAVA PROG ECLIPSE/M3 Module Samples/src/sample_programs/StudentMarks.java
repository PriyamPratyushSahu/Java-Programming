package sample_programs;

public class StudentMarks extends Student2 {
	private int sem;
	//private String name,deg,stream;
	private double m1,m2,m3;
}
