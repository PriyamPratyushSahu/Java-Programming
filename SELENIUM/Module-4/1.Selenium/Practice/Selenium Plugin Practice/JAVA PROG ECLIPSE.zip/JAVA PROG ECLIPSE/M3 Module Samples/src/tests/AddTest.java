package tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class AddTest {

	@Test
	public void test() 
	{
		assertEquals("not equal",3, 3);
	}

}
