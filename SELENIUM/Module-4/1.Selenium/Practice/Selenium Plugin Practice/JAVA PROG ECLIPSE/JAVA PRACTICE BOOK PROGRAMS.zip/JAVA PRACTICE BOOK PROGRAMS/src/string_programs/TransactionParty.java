package string_programs;

public class TransactionParty {
	String seller;
	String buyer;
	public TransactionParty(String seller, String buyer) {
		this.seller = seller;
		this.buyer = buyer;
	}
	
}
